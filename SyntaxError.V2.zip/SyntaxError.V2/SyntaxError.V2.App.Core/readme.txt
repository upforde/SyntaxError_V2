This core project is a .net standard project.
It's a great place to put all your logic that is not platform dependent (e.g. model/helper classes) so they can be reused.