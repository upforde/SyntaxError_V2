﻿using SyntaxError.V2.Modell.Challenges;
using SyntaxError.V2.Modell.Utility;
using System.Windows.Input;

namespace SyntaxError.V2.App.Helpers
{
    public class ListItemMainPage
    {
        public GameProfile GameProfile { get; set; }
        public ICommand DeleteCommandGameProfile { get; set; }

        public ChallengeBase Challenge { get; set; }
        public ICommand DeleteCommandChallenge { get; set; }
    }
}
