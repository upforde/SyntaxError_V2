﻿using Newtonsoft.Json;
using SyntaxError.V2.Modell.Challenges;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SyntaxError.V2.App.DataAccess
{
    public class Challenges
    {
        readonly HttpClient _httpClient = new HttpClient();
        static readonly Uri challengesBaseUri = new Uri("http://localhost:51749/api/Challenges");

        public async Task<ChallengeBase[]> GetChallengesAsync()
        {
            HttpResponseMessage result = await _httpClient.GetAsync(challengesBaseUri);
            string json = await result.Content.ReadAsStringAsync();
            ChallengeBase[] challenges = JsonConvert.DeserializeObject<ChallengeBase[]>(json);

            return challenges;
        }

        internal async Task<bool> DeleteChallengeAsync(ChallengeBase param)
        {
            HttpResponseMessage result = await _httpClient.DeleteAsync(new Uri(challengesBaseUri, "Challenges/" + param.ChallengeID.ToString()));
            return result.IsSuccessStatusCode;
        }
    }
}
