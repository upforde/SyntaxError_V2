﻿using System;

using SyntaxError.V2.App.Helpers;

namespace SyntaxError.V2.App.ViewModels
{
    public class CreateCrewViewModel : Observable
    {
        public CreateCrewViewModel()
        {
        }
    }
}
