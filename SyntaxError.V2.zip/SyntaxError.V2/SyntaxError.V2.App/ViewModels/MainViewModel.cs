﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using SyntaxError.V2.App.DataAccess;
using SyntaxError.V2.App.Helpers;
using SyntaxError.V2.Modell.Challenges;
using SyntaxError.V2.Modell.Utility;

namespace SyntaxError.V2.App.ViewModels
{
    public class MainViewModel : Observable
    {

        public ICommand DeleteGameProfileCommand { get; set; }
        public ICommand DeleteChallengeCommand { get; set; }

        public ObservableCollection<ListItemMainPage> GameProfiles { get; set; } = new ObservableCollection<ListItemMainPage>();
        private GameProfiles gameProfilesDataAccess = new GameProfiles();

        public ObservableCollection<ChallengeBase> Challenges { get; set; } = new ObservableCollection<ChallengeBase>();
        public Challenges challengesDataAccess = new Challenges();


        public MainViewModel()
        {
            DeleteGameProfileCommand = new RelayCommand<ListItemMainPage>(async param =>
                                                    {
                                                        if (await gameProfilesDataAccess.DeleteGameProfileAsync(param.GameProfile))
                                                            GameProfiles.Remove(param);
                                                    }, param => param != null);

            DeleteChallengeCommand = new RelayCommand<ChallengeBase>(async param =>
                                                    {
                                                        if (await challengesDataAccess.DeleteChallengeAsync(param))
                                                            Challenges.Remove(param);
                                                    }, param => param != null);
            
        }

        internal async Task LoadGameProfilesFromDBAsync()
        {
            var gameProfiles = await gameProfilesDataAccess.GetGameProfilesAsync();
            foreach(GameProfile gameProfile in gameProfiles)
            {
                GameProfiles.Add(new ListItemMainPage
                {
                    GameProfile = gameProfile,
                    DeleteCommandGameProfile = DeleteGameProfileCommand
                });
            }
        }

        internal async Task LoadChallengesFromDBAsync()
        {
            var challenges = await challengesDataAccess.GetChallengesAsync();
            foreach(ChallengeBase challenge in challenges)
            {
                Challenges.Add(challenge);
            }
        }
    }
}
