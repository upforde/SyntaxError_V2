﻿using System;

using SyntaxError.V2.App.Helpers;

namespace SyntaxError.V2.App.ViewModels
{
    public class CreateObjectsViewModel : Observable
    {
        public CreateObjectsViewModel()
        {
        }
    }
}
