﻿using System;

using SyntaxError.V2.App.ViewModels;
using SyntaxError.V2.Modell.Utility;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;

namespace SyntaxError.V2.App.Views
{
    public sealed partial class MainPage : Page
    {
        public MainViewModel ViewModel { get; } = new MainViewModel();

        public MainPage()
        {
            InitializeComponent();

            Loaded += MainPage_GameProfilesLoadedAsync;
        }

        private async void MainPage_GameProfilesLoadedAsync(object sender, RoutedEventArgs e)
        {
            await ViewModel.LoadGameProfilesFromDBAsync();
        }
    }
}
