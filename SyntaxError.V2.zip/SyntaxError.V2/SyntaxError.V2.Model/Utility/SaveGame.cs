﻿namespace SyntaxError.V2.Modell.Utility
{
    public class SaveGame: UsingBase
    {
    }
}
