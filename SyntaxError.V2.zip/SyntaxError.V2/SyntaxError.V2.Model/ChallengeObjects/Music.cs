﻿using SyntaxError.V2.Modell.ChallengeObjects;

namespace SyntaxError.V2.Modell.ChallengeObjects
{
    public class Music: MediaObject
    {
    }
}
