﻿namespace SyntaxError.V2.Modell.Challenges
{
    public class QuizChallenge: QuestionChallenge
    {
    }
}
