﻿using SyntaxError.V2.Modell.ChallengeObjects;

namespace SyntaxError.V2.Modell.Challenges
{
    public class ScreenshotChallenge: ImageChallenge
    {
    }
}
